import React from 'react'
import logo from "/Users/Jaypatel/Downloads/Project/Megablog/megablog/src/download-removebg-preview.png"

function Logo({}) {
  return (
    <img src={logo} alt="Logo" width = '100px'  />
  )
}

export default Logo